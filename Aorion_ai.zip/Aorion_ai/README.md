# AORION AI ChatBot

A WPF-based cybersecurity awareness chatbot built in C# that helps users learn about online safety and digital protection.

---

## Features

- Voice greeting on startup
- Username recognition and memory (returning users are welcomed back)
- Keyword-based AI responses covering cybersecurity topics
- Sentiment detection (responds to frustrated, confused, worried, happy, sad, angry users)
- Interest tracking (remembers what topics the user is interested in)
- Clean modern UI with dark theme

---

## Project Structure

```
Aorion_ai/
│
├── MainWindow.xaml          # Main UI layout (Home, Username, Chat screens)
├── MainWindow.xaml.cs       # Main logic, event handlers, AI chat engine
├── respond.cs               # Stores all chatbot answers and ignore words
├── user_name.cs             # Handles username input, storage and lookup
├── voice_greeting.cs        # Plays a voice greeting on app startup
├── greet.WAV                # Audio greeting file
├── logo.jpeg                # App logo displayed on home and username screens
├── user_names.txt           # Auto-created file that stores usernames
└── interested_topic.txt     # Auto-created file that stores user interests
```

---

## How It Works

### 1. Home Screen
When the app launches, a voice greeting plays and the home screen is displayed with a **Proceed** button.

### 2. Username Screen
The user enters their name. The app checks `user_names.txt`:
- **New user** → welcomed and name saved
- **Returning user** → welcomed back by name

### 3. Chat Screen
The user types questions and the chatbot responds based on keyword matching.

#### AI Engine Flow:
1. Input is cleaned (special characters removed)
2. Words are split and stop words are filtered out
3. Each word is mapped to a keyword (e.g. `"hello"` → `"greeting"`)
4. Matching answers are found from the `reply` ArrayList
5. The keyword prefix is stripped before displaying the answer
6. Every 3 messages, the bot reminds the user of their saved interests

---

## Cybersecurity Topics Covered

| Topic | Keywords |
|-------|----------|
| Cybersecurity | cybersecurity, security |
| Phishing | phishing |
| Firewall | firewall |
| Password Safety | password |
| Hacked Accounts | hacked, hack, compromised |
| Fraud | fraud |
| Malicious Chatbots | malicious, chatbot |
| VPN | vpn |
| Two-Factor Authentication | authentication, 2fa |
| Encryption | encryption |
| Ransomware | ransomware |
| Social Engineering | social, engineering |
| Data Breach | breach |
| Spyware | spyware |
| Antivirus | antivirus |
| Dark Web | darkweb |
| Identity Theft | identity |

---

## Sentiment Detection

The chatbot also detects emotional keywords and responds with empathy:

| Emotion | Trigger Word |
|---------|-------------|
| Frustrated | frustrated |
| Confused | confused |
| Worried | worried |
| Happy | happy |
| Sad | sad |
| Angry | angry |

---

## Interest Tracking

When a user says something like:
> *"I am interested in cybersecurity and encryption"*

The chatbot saves their interests to `interested_topic.txt` and every 3 messages reminds them of relevant topics.

---

## Requirements

- Windows OS
- .NET 8.0 or later
- Visual Studio 2022 or later

---

## How to Run

1. Clone or download the project
2. Open `Aorion_ai.sln` in Visual Studio
3. Make sure `greet.WAV` and `logo.jpeg` are set to **Copy Always** in Properties
4. Press **F5** to build and run

---

## Files Auto-Created at Runtime

| File | Purpose |
|------|---------|
| `user_names.txt` | Stores all usernames that have used the app |
| `interested_topic.txt` | Stores each user's topics of interest |

These files are created automatically in the app's working directory if they do not exist.

---

## Author

**Aorion AI** — Built as a cybersecurity awareness chatbot project.
