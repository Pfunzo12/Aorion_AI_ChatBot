﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Aorion_ai
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
